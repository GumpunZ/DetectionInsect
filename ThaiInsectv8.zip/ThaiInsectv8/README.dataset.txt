# ThaiInsect > 2023-10-24 8:40pm
https://universe.roboflow.com/khonkean-lq35k/thaiinsect

Provided by a Roboflow user
License: CC BY 4.0

